#!/system/bin/sh
#(c)kingbri KingKernel on boot tweaks

# Trim selected partitions at boot for a more than well-deserved and nice speed boost;
fstrim /data;
fstrim /cache;
fstrim /system;

#Force enable cpu3
echo "1" > /sys/devices/system/cpu/cpu3/online

# Disable & purge every possible trace of ZRAM and swapoff from the system and the kernel because they are not needed on a device that comes delivered with 4gb of RAM memory;
swapoff /dev/block/zram0;
echo "0" > /sys/block/zram0/disksize;
echo "1" > /sys/block/zram0/reset;

#Enable core control & msm_thermal for lesser cpu usage
echo "1" > /sys/module/msm_thermal/core_control/enabled
echo "Y" > /sys/module/msm_thermal/parameters/enabled

# Disable a couple of useless system daemons at boot;
stop debuggerd
stop healthd
stop performanced
stop perfd
stop statsd
stop tombstoned
stop incidentd
stop folio_daemon
