#!/system/bin/sh
# enable a few Google Play Services for better overall battery life during idle and when the phone is supposed to deep sleep;
pm enable com.google.android.gms/com.google.android.gms.analytics.service.AnalyticsService;
pm enable com.google.android.gms/com.google.android.gms.analytics.AnalyticsService;
pm enable com.google.android.gms/com.google.android.gms.analytics.AnalyticsTaskService;
pm enable com.google.android.gms/com.google.android.gms.analytics.internal.PlayLogReportingService
pm enable com.google.android.gms/com.google.android.gms.analytics.AnalyticsReceiver;
pm enable com.google.android.gms/com.google.android.gms.mdm.services.RingService;
pm enable com.google.android.gms/com.google.android.gms.mdm.services.NetworkQualityAndroidService;
pm enable com.google.android.gms/com.google.android.gms.mdm.services.MdmPhoneWearableListenerService;
pm enable com.google.android.gms/com.google.android.gms.mdm.services.LockscreenMessageService;
pm enable  com.google.android.gms/com.google.android.gms.mdm.services.DeviceManagerApiService;
pm enable com.google.android.gms/com.google.android.gms.mdm.services.GcmReceiverService;
pm enable com.google.android.gms/com.google.android.gms.mdm.receivers.MdmDeviceAdminReceiver;
pm enable com.google.android.gms/com.google.android.gms.mdm.receivers.RetryAfterAlarmReceiver;
pm enable com.google.android.gms/com.google.android.gms.checkin.CheckinServiceImposeReceiver;
pm enable com.google.android.gms/com.google.android.gms.checkin.CheckinServiceSecretCodeReceiver;
pm enable com.google.android.gms/com.google.android.gms.checkin.CheckinServiceTriggerReceiver;
pm enable com.google.android.gms/com.google.android.gms.checkin.EventLogService;
pm enable com.google.android.gms/com.google.android.gms.checkin.CheckinService;
pm enable com.google.android.gms/com.google.android.gms.checkin.CheckinApiService;
pm enable com.google.android.gms/com.google.android.gms.clearcut.debug.ClearcutDebugDumpService;
