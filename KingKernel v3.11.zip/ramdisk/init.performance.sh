#!/system/bin/sh
echo "1516800" > /sys/module/cpu_input_boost/parameters/input_boost_freq_lp 
echo "1363200" > /sys/module/cpu_input_boost/parameters/input_boost_freq_hp 
echo "125" > /sys/module/cpu_input_boost/parameters/input_boost_duration 
echo "performance" >  /sys/class/kgsl/kgsl-3d0/devfreq/governor
