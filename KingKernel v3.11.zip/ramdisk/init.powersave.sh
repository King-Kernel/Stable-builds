#!/system/bin/sh
echo "979200" > /sys/module/cpu_input_boost/parameters/input_boost_freq_lp
echo "0" > /sys/module/cpu_input_boost/parameters/input_boost_freq_hp 0
echo "32" /sys/module/cpu_input_boost/parameters/input_boost_duration 
echo "powersave" /sys/class/kgsl/kgsl-3d0/devfreq/governor dev
