#!/system/bin/sh
echo "1056000" > /sys/module/cpu_input_boost/parameters/input_boost_freq_lp 
echo "902400" > /sys/module/cpu_input_boost/parameters/input_boost_freq_hp 
echo "64" > /sys/module/cpu_input_boost/parameters/input_boost_duration 
echo "msm-adreno-tz" > /sys/class/kgsl/kgsl-3d0/devfreq/governor !/sys
